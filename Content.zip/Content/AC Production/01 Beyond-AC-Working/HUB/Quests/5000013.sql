
DELETE FROM `quest` WHERE (`id` = '5000013');
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`, `last_Modified`) VALUES ('5000013', 'WardenFrore', '0', '1', 'Frore Fac Hub', '2019-09-05 11:37:00');