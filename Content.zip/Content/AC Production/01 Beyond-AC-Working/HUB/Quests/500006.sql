
DELETE FROM `quest` WHERE (`id` = '500006');
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`, `last_Modified`) VALUES ('500006', 'OH', '0', '1', 'Olthoi Helm', '2019-09-05 19:03:38');