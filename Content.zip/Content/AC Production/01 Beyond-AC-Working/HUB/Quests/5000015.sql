
DELETE FROM `quest` WHERE (`id` = '5000015');
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`, `last_Modified`) VALUES ('5000015', 'WardenAtlan', '0', '1', 'Atlan Fac Hub', '2019-09-05 11:37:00');
