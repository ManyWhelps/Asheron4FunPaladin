
DELETE FROM `quest` WHERE (`id` = '5000017');
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`, `last_Modified`) VALUES ('5000017', 'WardenYO', '0', '1', 'Young olthoi brood Queen', '2019-09-05 11:37:00');
