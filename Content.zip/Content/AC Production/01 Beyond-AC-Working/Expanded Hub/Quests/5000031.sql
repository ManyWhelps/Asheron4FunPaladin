
DELETE FROM `quest` WHERE (`id` = '5000031');
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`, `last_Modified`) VALUES ('5000031', 'WardenDaviator', '0', '1', 'WardenDaviator', '2019-09-05 19:03:38');