
DELETE FROM `quest` WHERE (`id` = '5000027');
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`, `last_Modified`) VALUES ('5000027', 'WardenHOI', '0', '1', 'WardenHOI', '2019-09-05 19:03:38');