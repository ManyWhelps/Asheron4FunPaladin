
DELETE FROM `quest` WHERE (`id` = '5000025');
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`, `last_Modified`) VALUES ('5000025', 'WardenAegis', '0', '1', 'WardenAegis', '2019-09-05 19:03:38');