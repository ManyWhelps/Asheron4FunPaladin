
DELETE FROM `quest` WHERE (`id` = '5000020');
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`, `last_Modified`) VALUES ('5000020', 'WardenArcane', '0', '1', 'WardenArcane', '2019-09-05 19:03:38');