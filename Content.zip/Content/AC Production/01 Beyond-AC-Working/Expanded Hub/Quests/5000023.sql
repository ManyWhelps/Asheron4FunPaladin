
DELETE FROM `quest` WHERE (`id` = '5000023');
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`, `last_Modified`) VALUES ('5000023', 'WardenFlag', '0', '1', 'WardenFlag', '2019-09-05 19:03:38');