

DELETE FROM `quest` WHERE `name` = 'illusiondragon'; 



INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`) VALUES ('999504', 'illusiondragon', '0', '10', 'Illusion Dragon');