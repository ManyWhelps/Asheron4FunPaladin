DELETE FROM `quest` WHERE `name` = 'NIGun';
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`) VALUES ('999502', 'NIGun', '0', '10', 'Ore for Gun');