
DELETE FROM `quest` WHERE `name` = 'Toothpick';
INSERT INTO `quest` (`id`, `name`, `min_Delta`, `max_Solves`, `message`) VALUES ('999503', 'Toothpick', '0', '10', 'Toothpick');