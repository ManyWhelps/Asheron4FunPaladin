
Delete FROM landblock_instance where landblock=29448 and weenie_Class_Id=2000007;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
	VALUES (0x77308500, 2000007, 1929904136, 23.148819, 190.159027, 4.169966, -0.853781, 0.000000, 0.000000, -0.520632, False, '2019-07-27 14:14:00'); /* Linkable Monster Generator ( 5 Min.) */
/* @teleloc 73080008 23.148819 190.159027 4.169966 -0.853781 0.000000 0.000000 -0.520632 */;
