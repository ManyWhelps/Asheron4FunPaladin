DELETE FROM landblock_instance WHERE landblock=0x0133 AND weenie_Class_Id=42847;

INSERT INTO `landblock_instance` (`guid`,`weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
	VALUES (0x70133500, 42847, 20119846, 30.0104, -62.1518, 5.937, -0.00420367, 0, 0, -0.999991, False, '2019-07-27 14:14:00'); /* Linkable Monster Generator ( 5 Min.) */
/* @teleloc 01330126 30.0104 -62.1518 5.937 -0.00420367 0 0 -0.999991 */;