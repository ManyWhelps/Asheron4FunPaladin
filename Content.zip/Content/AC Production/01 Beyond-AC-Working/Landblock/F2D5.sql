DELETE FROM `landblock_instance` WHERE `landblock` = 0xF2D5;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F2D5000, 5000767, 0xF2D50030, 135.163, 191.734, -0.045, 0.365577, 0, 0, -0.930781, False, '2020-05-20 20:57:40'); /* Wasp gen */
/* @teleloc 0xF2D50030 [135.162994 191.733994 -0.045000] 0.365577 0.000000 0.000000 -0.930781 */

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7F2D5001, 5000767, 0xF2D50038, 160.66881, 187.83408, -0.044999998, 0.99981374, 0, 0, 0.019298743, False, '2020-05-20 20:57:43'); /* Wasp gen */
/* @teleloc 0xF2D50038 [160.668808 187.834076 -0.045000] 0.999814 0.000000 0.000000 0.019299 */
