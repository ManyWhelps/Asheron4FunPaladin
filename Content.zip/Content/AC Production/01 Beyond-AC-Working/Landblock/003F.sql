DELETE FROM `landblock_instance` WHERE `landblock` =63;

INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES (0x7003F005, 5000716, 0x003F0187, 192.7657, -257.1856, -41.995, -0.413477, 0, 0, -0.9105145, False, '2020-01-20 00:26:08'); /* Byron Dalton Assistant to Three Fingers */
/* @teleloc 0x003F0187 [192.7657 -257.1856 -41.995] -0.413477 0 0 -0.9105145 */


