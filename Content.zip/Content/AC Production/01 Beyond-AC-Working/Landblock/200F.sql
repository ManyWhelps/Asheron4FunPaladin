DELETE FROM `landblock_instance` WHERE `landblock` =8207;




INSERT INTO `landblock_instance` (`guid`, `weenie_Class_Id`, `obj_Cell_Id`, `origin_X`, `origin_Y`, `origin_Z`, `angles_W`, `angles_X`, `angles_Y`, `angles_Z`, `is_Link_Child`, `last_Modified`)
VALUES(0x7200F000, 5000669, 0x200F0A02, 27.03816, 20.8433, -35.663, 0.8892929, 0, 0, 0.4573381, False, '2020-01-18 01:09:35'); /* Rogue Portal */
/* @teleloc 0x200F0A02 [27.03816 20.8433 -35.663] 0.8892929 0 0 0.4573381 */
